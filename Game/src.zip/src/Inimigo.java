public interface Inimigo {
    String nome();
    int ataque();
    int BarraDeVida();
}

