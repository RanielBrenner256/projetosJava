public class ArmaLaser implements Arma {
    public String nome() {
        return "Laser"; }
    public int dano() {
        return 8; }
}
