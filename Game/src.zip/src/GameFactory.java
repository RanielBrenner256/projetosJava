public interface GameFactory {
    Inimigo criarInimigo();
    Arma criarArma();
}
