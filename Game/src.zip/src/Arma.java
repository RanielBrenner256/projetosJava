public interface Arma {
    String nome();
    int dano();
}
