public class Espada implements Arma {
    public String nome() {
        return "Espada Longa"; }
    public int dano() {
        return 8;
    }
}
